#!/usr/bin/env python3
import subprocess, json, os, platform, time, io, requests
from prettytable import PrettyTable
from math import isnan

BOT_TOKEN = "8092854267:AAFtwPVoc7I3gS0U15obBsK7PzCWdJdxzTI"
CHAT_ID = "-1003360240840"   # your channel ID

# === Detect platform and paths ===
is_windows = platform.system().lower().startswith("win")
base_path = (
    os.path.join(os.getcwd(), "bin", "Release")
    if is_windows
    else os.path.join(os.getcwd(), "bin")
)

def build_path(cmd):
    exe = cmd.split()[0]
    if not exe.endswith(".exe") and is_windows:
        exe += ".exe"
    return os.path.join(base_path, exe) + " " + " ".join(cmd.split()[1:])

def run_benchmark():
    # === Benchmark commands ===
    raw_cmds = [
        "info_cuda_bench",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP64 --accprecision FP64 --cudacoresonly",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP32 --accprecision FP32 --cudacoresonly",
        "gemm_cuda_bench --benchsec 5 --mulprecision BF16 --accprecision FP32 --cudacoresonly",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP16 --accprecision FP32 --cudacoresonly",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP16 --accprecision FP16 --cudacoresonly",
        "gemm_cuda_bench --benchsec 5 --mulprecision INT8 --accprecision INT32 --cudacoresonly",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP64 --accprecision FP64",
        "gemm_cuda_bench --benchsec 5 --mulprecision TF32 --accprecision FP32",
        "gemm_cuda_bench --benchsec 5 --mulprecision BF16 --accprecision FP32",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP16 --accprecision FP32",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP16 --accprecision FP16",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP8_E4M3 --accprecision FP32",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP8_E5M2 --accprecision FP32",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP6_E3M2 --accprecision FP32",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP6_E2M3 --accprecision FP32",
        "gemm_cuda_bench --benchsec 5 --mulprecision FP4_E2M1 --accprecision FP32",
        "gemm_cuda_bench --benchsec 5 --mulprecision INT8 --accprecision INT32",
        "gemm_cuda_bench --benchsec 5 --mulprecision INT4 --accprecision INT32",
    ]
    commands = [build_path(c) for c in raw_cmds]

    # === Run all and parse stderr JSON ===
    raw_results = []
    for cmd in commands:
        print(f"▶ {cmd}")
        try:
            proc = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stderr_json = proc.stderr.strip()
            if not stderr_json:
                print("⚠️ No stderr JSON, skipping.\n")
                continue
            try:
                parsed = json.loads(stderr_json)
                raw_results.append(parsed)
                print("✅ Parsed JSON.\n")
            except json.JSONDecodeError:
                print("❌", stderr_json[:200],"\n")
        except Exception as e:
            print(f"💥 Error: {e}\n")
    
    
    # === Merge results into consistent bench_info lists ===
    merged = {"devices": []}
    device_map = {}

    for result in raw_results:
        for dev in result.get("devices", []):
            idx = dev.get("device_index")
            uuid = dev.get("device_uuid", f"GPU-{idx}")
            key = uuid or f"GPU-{idx}"

            # Create entry if new GPU
            if key not in device_map:
                info = dev.get("device_info", {})
                device_entry = {
                    "device_index": idx,
                    "device_uuid": uuid,
                    "device_info": info,
                    "bench_info": []  # Always list
                }
                device_map[key] = device_entry
                merged["devices"].append(device_entry)

            # Convert any bench_info to list form and merge
            bench_data = dev.get("bench_info")
            if bench_data:
                if isinstance(bench_data, dict):
                    device_map[key]["bench_info"].append(bench_data)
                elif isinstance(bench_data, list):
                    device_map[key]["bench_info"].extend(bench_data)


    # === Print per-GPU summary table ===
    for dev in reversed(merged["devices"]):

        gpu_name = dev["device_info"].get("name", "Unknown GPU")
        gpu_idx = dev.get("device_index", "?")
        gpu_num_sms = dev["device_info"].get("num_sms", "?")
        gpu_num_cuda_cores = dev["device_info"].get("num_cuda_cores", "?")
        gpu_num_tensor_cores = dev["device_info"].get("num_tensor_cores", "?")
        gpu_pci_id = dev["device_info"].get("pci_id", "?")
        gpu_pci_subsystem_id = dev["device_info"].get("pci_subsystem_id", "?")
        gpu_sm_clock_mhz = dev["device_info"].get("sm_clock_mhz", "?")
        gpu_memory_clock_mhz = dev["device_info"].get("memory_clock_mhz", "?")  
        global_mem_bus_bw_gbps = dev["device_info"].get("global_mem_bus_bw_gbps", "?")
        cuda_runtime_version = dev["device_info"].get("runtime_version", "?")
        cuda_compiler_version = dev["device_info"].get("compiler_version", "?")

        table = PrettyTable()
        table.field_names = ["Precision (Mul→Acc)", "Tensor Cores", "TeraOps (TFLOPS or TOPS)", "Average Power (W)","Efficiency (TeraOps/W)"]

        for b in dev.get("bench_info", []):
            conf = b.get("config", {})
            perf = b.get("performance", {})
            mul, acc = conf.get("gmulprecision", "?"), conf.get("gaccprecision", "?")
            tensor = "Yes" if conf.get("gtensor_cores") else "No"
            tera_ops = perf.get("tera_ops")
            tera_ops_str = "N/A" if tera_ops in (None, 0) else f"{tera_ops:.2f}"
            tera_ops_per_W = perf.get("tera_ops_per_W")
            tera_ops_per_W_str = "N/A" if tera_ops_per_W in (None, 0) else f"{tera_ops_per_W:.2f}"
            avg_power_W = perf.get("avg_power_W")
            avg_power_W_str = "N/A" if avg_power_W in (None, 0) else f"{avg_power_W:.2f}"
            table.add_row([f"{mul}→{acc}", tensor, tera_ops_str, avg_power_W_str, tera_ops_per_W_str])

        print(f"\n📊 CUDA GEMM Benchmark (Runtime {cuda_runtime_version}, Compiler {cuda_compiler_version}) — GPU {gpu_idx}: {gpu_name} [{gpu_pci_id} {gpu_pci_subsystem_id}]\n(SMs: {gpu_num_sms}, CUDAs: {gpu_num_cuda_cores}, Tensors: {gpu_num_tensor_cores}, Core: {gpu_sm_clock_mhz} MHz, Mem: {gpu_memory_clock_mhz} MHz, Bandwidth: {global_mem_bus_bw_gbps} GB/s)")
        print(table)

    return merged

def submit_json(data):
    # encode JSON to bytes in memory
    json_bytes = json.dumps(data, indent=2).encode("utf-8")

    # safely extract GPU info
    try:
        info = data["devices"][0]["device_info"]
        gpu_name = info.get("name", "UnknownGPU")
        pci_id = info.get("pci_id", "unknown")
        pci_subsys = info.get("pci_subsystem_id", "unknown")
    except Exception:
        gpu_name = "UnknownGPU"
        pci_id = "unknown"
        pci_subsys = "unknown"

    # cleaning function for filename
    def clean(val):
        return str(val).replace(" ", "_").replace("/", "_").replace(":", "")

    gpu_name = clean(gpu_name)
    pci_id = clean(pci_id)
    pci_subsys = clean(pci_subsys)

    # timestamp (ms)
    ts = int(time.time() * 1000)

    # final filename: GPUName_PCIID_PCI_SUBSYS_timestamp.json
    filename = f"{gpu_name}_{pci_id}_{pci_subsys}_{ts}.json"

    # wrap bytes in BytesIO for Telegram
    fileobj = io.BytesIO(json_bytes)
    fileobj.name = filename

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"

    r = requests.post(
        url,
        data={"chat_id": CHAT_ID},
        files={"document": (filename, fileobj, "application/json")}
    )

    print(r.json())

merged = run_benchmark()
print(merged)
submit_json(merged)

# Targeted GPU
# RTX 2070 Super, Tesla T4
# RTX 2060 Super, CMP 40HX
# RTX 3080, RTX A5000
# RTX 3090, RTX A6000

